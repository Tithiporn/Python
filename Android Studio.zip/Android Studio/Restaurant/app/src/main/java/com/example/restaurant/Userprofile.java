package com.example.restaurant;

//for sign up activity

public class Userprofile {

    public String userName;
    public String userEmail;

    public Userprofile(String userName, String userEmail) {
        this.userName = userName;
        this.userEmail = userEmail;
    }
}

